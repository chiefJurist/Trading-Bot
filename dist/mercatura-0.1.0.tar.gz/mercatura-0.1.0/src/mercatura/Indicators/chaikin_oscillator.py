import os 
from dotenv import load_dotenv
import ccxt
import pandas as pd
import talib as ta
import time
import math
import numpy as np

load_dotenv()

# The User's API keys and addresses
SPOT_API_KEY = os.getenv('SPOT_API_KEY')
SPOT_SECRET_KEY = os.getenv('SPOT_SECRET_KEY')
FUTURES_API_KEY = os.getenv('FUTURES_API_KEY')
FUTURES_SECRET_KEY = os.getenv('FUTURES_SECRET_KEY')
ADDRESS_ONE = os.getenv('ADDRESS_ONE')

# Initialize the Binance Spot exchange
binance_spot = ccxt.binance({
    'apiKey': SPOT_API_KEY,
    'secret': SPOT_SECRET_KEY,
})

# Initialize the Binance Futures exchange
binance_futures = ccxt.binanceusdm({
    'apiKey': FUTURES_API_KEY,
    'secret': FUTURES_SECRET_KEY,
})

#Function For Fetching OHLCV
def fetch_OHLCV(symbol, timeframe, limit=500):
    bars = binance_futures.fetch_ohlcv(symbol, timeframe, limit=limit)
    df = pd.DataFrame(bars, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df

# Function to calculate Chaikin A/D Oscillator
def calculate_chaikin_oscillator(df, fast_period=3, slow_period=10):
    # Ensure high, low, close, and volume columns are present
    if not all(col in df.columns for col in ['high', 'low', 'close', 'volume']):
        raise ValueError("Missing required columns in DataFrame")

    # Calculate the Chaikin A/D Line
    ad_line = ta.AD(df['high'], df['low'], df['close'], df['volume'])

    # Calculate the EMA of the A/D Line
    ema_fast = ta.EMA(ad_line, timeperiod=fast_period)
    ema_slow = ta.EMA(ad_line, timeperiod=slow_period)

    # Calculate the Chaikin A/D Oscillator
    ad_oscillator = ema_fast - ema_slow

    # Combine with timestamp and close price in the output
    result = [
        [idx, row['timestamp'], {'close': row['close'], 'ad_oscillator': osc}]
        for idx, (row, osc) in enumerate(zip(df.to_dict('records'), ad_oscillator))
    ]

    return result

# Parameters
symbol = 'ETH/USDT'  # Example trading pair
timeframe = '1m'  # Example timeframe
timeframe2 = '5m'  # Example timeframe 2
limit = 500  # Number of candles to fetch

# Fetch OHLCV data
ohlcv_data = fetch_OHLCV(symbol, timeframe, limit)
ohlcv_data2 = fetch_OHLCV(symbol, timeframe2, limit)

# Calculate Chaikin A/D Oscillator
chaikin_osc_result = calculate_chaikin_oscillator(ohlcv_data)
chaikin_osc_result2 = calculate_chaikin_oscillator(ohlcv_data2)

# Print the results
print("1 MINUTE CHART")
for entry in chaikin_osc_result:
    print(entry)
print("")
print("5 MINUTE CHART")
for entry in chaikin_osc_result2:
    print(entry)